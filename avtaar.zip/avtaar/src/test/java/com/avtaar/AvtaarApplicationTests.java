package com.avtaar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvtaarApplicationTests {

	@Test
	void contextLoads() {
	}

}
